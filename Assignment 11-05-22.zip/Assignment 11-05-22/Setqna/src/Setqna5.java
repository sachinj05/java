/*5. Write a Java program to append the specified element to the end of a hash set and iterate through all
elements in a hash list*/

import java.util.HashSet;

public class Setqna5 {
    public static void main(String[] args) {
        HashSet<String>h1 = new HashSet<>();
        h1.add("Tiger");
        h1.add("Lion");
        h1.add("Elephant");
        h1.add("Deer");
        h1.add("Rabbit");
        h1.add("Beer");
        System.out.println(h1);
    }
}
