//1. Write a Java program to create a new array list, add some elements (string) and print out the collection.

import java.util.ArrayList;

public class Listqna1 {
    public static void main(String[] args) {
        ArrayList<String>a1 = new ArrayList<>();
        a1.add ("Sachin");
        a1.add ("Satya");
        a1.add ("Siva");
        a1.add ("Amit");
        a1.add ("Smruti");
        a1.add ("Sweety");
        System.out.println(a1);
    }
}
